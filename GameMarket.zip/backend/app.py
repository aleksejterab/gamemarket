import os
from datetime import datetime, timedelta, timezone
from typing import Optional
from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import jwt, JWTError
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import create_engine, String, Integer, Boolean, DateTime, ForeignKey, Text, Float
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session
load_dotenv()
SECRET_KEY=os.getenv("SECRET_KEY","DEV-ONLY-change-before-deploy")
ALGORITHM="HS256"; TOKEN_MINUTES=int(os.getenv("ACCESS_TOKEN_MINUTES","60"))
URL=os.getenv("DATABASE_URL","sqlite:///./gamemarket.db")
engine=create_engine(URL,connect_args={"check_same_thread":False} if URL.startswith("sqlite") else {},pool_pre_ping=True)
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)
class Base(DeclarativeBase): pass
class User(Base):
 __tablename__="users"
 id:Mapped[int]=mapped_column(Integer,primary_key=True)
 email:Mapped[str]=mapped_column(String(320),unique=True,index=True)
 username:Mapped[str]=mapped_column(String(32),unique=True,index=True)
 password_hash:Mapped[str]=mapped_column(String(255))
class Listing(Base):
 __tablename__="listings"
 id:Mapped[int]=mapped_column(Integer,primary_key=True)
 title:Mapped[str]=mapped_column(String(120),index=True)
 description:Mapped[str]=mapped_column(Text)
 game:Mapped[str]=mapped_column(String(80),index=True)
 category:Mapped[str]=mapped_column(String(50))
 price_eur:Mapped[float]=mapped_column(Float)
 seller_id:Mapped[int]=mapped_column(ForeignKey("users.id"),index=True)
 active:Mapped[bool]=mapped_column(Boolean,default=True)
 created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
 seller:Mapped[User]=relationship()
class Order(Base):
 __tablename__="orders"
 id:Mapped[int]=mapped_column(Integer,primary_key=True)
 listing_id:Mapped[int]=mapped_column(ForeignKey("listings.id"))
 buyer_id:Mapped[int]=mapped_column(ForeignKey("users.id"))
 seller_id:Mapped[int]=mapped_column(ForeignKey("users.id"))
 amount_eur:Mapped[float]=mapped_column(Float)
 status:Mapped[str]=mapped_column(String(24),default="pending")
 created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
Base.metadata.create_all(engine)
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto"); oauth=OAuth2PasswordBearer(tokenUrl="/auth/token")
app=FastAPI(title="GameMarket API",version="0.1.0",description="Starter API; real payment processing is not implemented.")
app.add_middleware(CORSMiddleware,allow_origins=[os.getenv("FRONTEND_ORIGIN","http://127.0.0.1:5500")],allow_credentials=True,allow_methods=["GET","POST","PATCH"],allow_headers=["Authorization","Content-Type"])
def get_db():
 db=SessionLocal()
 try: yield db
 finally: db.close()
class RegisterIn(BaseModel):
 email:EmailStr
 username:str=Field(min_length=3,max_length=32,pattern=r"^[A-Za-z0-9_-]+$")
 password:str=Field(min_length=10,max_length=72)
class ListingIn(BaseModel):
 title:str=Field(min_length=4,max_length=120); description:str=Field(min_length=10,max_length=5000)
 game:str=Field(min_length=2,max_length=80); category:str=Field(min_length=2,max_length=50)
 price_eur:float=Field(gt=0,le=100000)
class ListingOut(BaseModel):
 id:int; title:str; description:str; game:str; category:str; price_eur:float; seller_id:int
 model_config={"from_attributes":True}
class OrderIn(BaseModel): listing_id:int
class OrderOut(BaseModel):
 id:int; listing_id:int; buyer_id:int; seller_id:int; amount_eur:float; status:str
 model_config={"from_attributes":True}
def token_for(u):
 return jwt.encode({"sub":str(u.id),"exp":datetime.now(timezone.utc)+timedelta(minutes=TOKEN_MINUTES)},SECRET_KEY,algorithm=ALGORITHM)
def current_user(token:str=Depends(oauth),db:Session=Depends(get_db)):
 try: uid=int(jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM]).get("sub",""))
 except (JWTError,ValueError,TypeError): raise HTTPException(401,"Invalid or expired token")
 u=db.get(User,uid)
 if not u: raise HTTPException(401,"User not found")
 return u
@app.get("/")
def root(): return {"service":"GameMarket API","docs":"/docs","payments":"not configured"}
@app.post("/auth/register",status_code=201)
def register(d:RegisterIn,db:Session=Depends(get_db)):
 if db.query(User).filter((User.email==d.email.lower())|(User.username==d.username)).first(): raise HTTPException(409,"Email or username already registered")
 u=User(email=d.email.lower(),username=d.username,password_hash=pwd.hash(d.password)); db.add(u); db.commit(); db.refresh(u)
 return {"id":u.id,"email":u.email,"username":u.username,"access_token":token_for(u),"token_type":"bearer"}
@app.post("/auth/token")
def login(f:OAuth2PasswordRequestForm=Depends(),db:Session=Depends(get_db)):
 u=db.query(User).filter(User.email==f.username.lower()).first()
 if not u or not pwd.verify(f.password,u.password_hash): raise HTTPException(401,"Incorrect email or password")
 return {"access_token":token_for(u),"token_type":"bearer"}
@app.get("/me")
def me(u:User=Depends(current_user)): return {"id":u.id,"email":u.email,"username":u.username}
@app.get("/listings",response_model=list[ListingOut])
def listings(q:Optional[str]=None,game:Optional[str]=None,db:Session=Depends(get_db)):
 query=db.query(Listing).filter(Listing.active==True)
 if q: query=query.filter(Listing.title.ilike("%"+q[:80]+"%"))
 if game: query=query.filter(Listing.game.ilike("%"+game[:80]+"%"))
 return query.order_by(Listing.created_at.desc()).limit(100).all()
@app.post("/listings",response_model=ListingOut,status_code=201)
def create_listing(d:ListingIn,u:User=Depends(current_user),db:Session=Depends(get_db)):
 x=Listing(**d.model_dump(),seller_id=u.id); db.add(x); db.commit(); db.refresh(x); return x
@app.post("/orders",response_model=OrderOut,status_code=201)
def create_order(d:OrderIn,u:User=Depends(current_user),db:Session=Depends(get_db)):
 x=db.get(Listing,d.listing_id)
 if not x or not x.active: raise HTTPException(404,"Listing unavailable")
 if x.seller_id==u.id: raise HTTPException(400,"Cannot buy your own listing")
 o=Order(listing_id=x.id,buyer_id=u.id,seller_id=x.seller_id,amount_eur=x.price_eur,status="pending")
 db.add(o); db.commit(); db.refresh(o); return o
@app.get("/orders/mine",response_model=list[OrderOut])
def my_orders(u:User=Depends(current_user),db:Session=Depends(get_db)):
 return db.query(Order).filter((Order.buyer_id==u.id)|(Order.seller_id==u.id)).order_by(Order.created_at.desc()).limit(100).all()
